n = int(input())

output = ""

for i in range(1, n+1):
    output += str(i)  
print(output)
