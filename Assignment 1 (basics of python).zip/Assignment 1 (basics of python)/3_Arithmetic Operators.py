a=int(input("Enter a value: "))
b=int(input("Enter b value: "))

print("Sum of two numbers: ",a+b)
print("Difference of two numbers: ",a-b)
print("Product of two numbers: ",a*b)