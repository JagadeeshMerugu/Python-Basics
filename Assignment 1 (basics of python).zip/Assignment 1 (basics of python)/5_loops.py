n=int(input("Enter a number:"))

for i in range(n):
    n=n+1
    print(i**2)