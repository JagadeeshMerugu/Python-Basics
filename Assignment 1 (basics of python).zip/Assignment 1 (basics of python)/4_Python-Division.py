a=int(input("Enter a value: "))
b=int(input("Enter b value: "))

print("Integer division:",a//b)
print("Float division:",a/b)